$(document).ready(() => {
    $('#logoutBtn').click((e) => {
        window.location.href = '../Pages/index.html';
    })

    $('#editQuestion').click(() => {
        window.location.href = '../Pages/edit_question.html';
    })
})