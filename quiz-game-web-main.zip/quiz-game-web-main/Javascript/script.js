$(document).ready(function () {
    $("#quiz").click(function () {
        window.location.href = "../Pages/quiz.html";
    })

    $("#about").click(function () {
        window.location.href = "../Pages/topic.html";
    })

    $("#highScore").click(function () {
        window.location.href = "../Pages/high_score.html";
    })

    $('#adminSignup').click(function () {
        window.location.href = "../Pages/signup.html";
    })

    $('#adminLogin').click(function () {
        window.location.href = "../Pages/login.html";
    })
})