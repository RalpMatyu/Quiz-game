# quiz-game-web
Quiz page like a game || Language Used: HTML/CSS/Javascript/Jquery/PHP
